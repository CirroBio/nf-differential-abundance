#!/bin/bash



./ArcticFreshwaters_split.sh
./Blueberry_splits.sh
./cdi_schubert_splits.sh
./hiv_noguerajulian_splits.sh
./Ji_WTP_DS_split.sh
./Ob_goodrich_generate_rand_splits.sh
./Office_splits.sh
./sw_sed_splits.sh
