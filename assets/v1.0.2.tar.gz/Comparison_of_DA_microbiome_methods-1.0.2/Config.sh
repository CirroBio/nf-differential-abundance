DATA_DIR="/home/jacob/projects/HACKATHON_ANCOM_FIX_21_03_13/Hackathon"
ANCOM_DIR="/home/jacob/GitHub_Repos/Clean_Hackathon/Pipeline_scripts/Ancom2_Script"
TOOL_DIR="/home/jacob/GitHub_Repos/Clean_Hackathon/Pipeline_scripts/Tool_scripts/"
